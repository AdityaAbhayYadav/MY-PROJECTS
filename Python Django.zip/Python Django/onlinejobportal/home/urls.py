#from django.contrib import admin
from django.urls import path
#from home import views
from . import views
urlpatterns = [
    #path('admin/', admin.site.urls),
    path('onlinejobportal/',views.index ),
    path('about/',views.about),
    path('post/',views.post),
    path('findjob/',views.findjob),
    path('contact/',views.contact),
    path('signup/',views.signup),
    path('login/',views.login)
    
]
