from django.shortcuts import render 
from django.http import HttpResponse
from .models import*
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from django.views import View
from django.shortcuts import redirect

# Create your views here.
def index(request):
    #return HttpResponse("sucessfull")
     return render(request,'index.html')

def about(request):
    #return HttpResponse("This About the Website")
     return render(request,'about.html')

def post(request):
    #return HttpResponse("This About the Services")
     return render(request,'post.html')
def findjob(request):
     return render(request,'findjob.html')

def contact(request):
    #return HttpResponse("This About the contact")
     return render(request,'contact.html')

from django.contrib.auth.models import User
from django.shortcuts import render, redirect

def signup(request):
    error = ""

    if request.method == 'POST':
        a = request.POST.get('exampleInputusername1')
        b = request.POST.get('exampleInputEmail1')
        c = request.POST.get('exampleInputPassword1')

        try:
            user = User.objects.create_user(username=a, email=b, password=c)
            # Successful user creation, set error to "no"
            error = "no"
        except Exception as e:
            # Exception occurred during user creation, set error to "yes"
            error = "yes"

    if error == "no":
        # Redirect to the login page if user creation was successful
        return redirect('/home/login')

    d = {'error': error}
    return render(request, 'signup.html', d)

            

'''def validateCustomer(self, customer):
        error_message = None;
        if (not customer.first_name):
            error_message = "First Name Required !!"
        elif len(customer.first_name) < 3:
            error_message = 'First Name must be 3 char long or more'
        elif not customer.last_name:
            error_message = 'Last Name Required !!'
        elif len(customer.last_name) < 3:
            error_message = 'Last Name must be 3 char long or more'
        elif len(customer.email) < 3:
            error_message = 'Email must be 3 char long or more'
        elif not customer.password:
            error_message = 'Password Required !!'
        elif len(customer.password) < 3:
            error_message = 'Password must be 3 char long or more'
        elif not customer.phone:
            error_message = 'Phone number Required !!'
        elif len(customer.phone) < 10:
            error_message = 'Phone number must be 10 char long or more'

        elif customer.isExists():
            error_message = 'Email Address Already Registered..'
            # saving
        return error_message
    '''

def login(request):
     
     return render(request,'login.html')
